package com.akjournal

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.roundToInt

class MainActivity: Activity(){
    val bg=Color.rgb(8,10,15); val card=Color.rgb(17,20,28); val card2=Color.rgb(22,25,35)
    val purple=Color.rgb(139,92,246); val green=Color.rgb(34,197,94); val red=Color.rgb(239,68,68)
    lateinit var content: LinearLayout
    fun text(s:String,size:Float=14f,bold:Boolean=false,color:Int=Color.WHITE)=TextView(this).apply{
        text=s;textSize=size;setTextColor(color);if(bold)setTypeface(null,1);setPadding(0,4,0,4)
    }
    fun box(pad:Int=18)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setPadding(pad,pad,pad,pad)
        background=GradientDrawable().apply{setColor(card);cornerRadius=22f}
    }
    fun gap(h:Int)=Space(this).apply{layoutParams=LinearLayout.LayoutParams(1,h)}
    override fun onCreate(b:Bundle?){super.onCreate(b);home()}
    fun base(title:String,sub:String){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(20,22,20,10)}
        val brand=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        brand.addView(text(title,24f,true));brand.addView(text(sub,12f,false,Color.LTGRAY))
        head.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        val b=Button(this).apply{text="+  Add Trade";setOnClickListener{addTrade()}}
        head.addView(b);root.addView(head)
        content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,8,16,90)}
        val sc=ScrollView(this);sc.addView(content);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setBackgroundColor(Color.rgb(13,15,22));setPadding(4,8,4,8)}
        listOf("⌂\nHome","▣\nTrades","▦\nCalendar","◈\nAnalytics","✎\nJournal").forEachIndexed{i,s->
            val n=text(s,11f,true,Color.LTGRAY);n.gravity=Gravity.CENTER;n.setOnClickListener{when(i){0->home();1->trades();2->calendar();3->analytics();4->journal()}}
            nav.addView(n,LinearLayout.LayoutParams(0,62,1f))
        };root.addView(nav)
        setContentView(root)
    }
    fun stat(title:String,value:String,delta:String,positive:Boolean=true):LinearLayout{
        val c=box();c.addView(text(title,12f,false,Color.LTGRAY));c.addView(text(value,22f,true))
        c.addView(text(delta,12f,true,if(positive)green else red))
        return c
    }
    fun home(){
        base("A.K JOURNAL","MAVEN-INSPIRED TRADING DASHBOARD")
        content.addView(text("Overview",18f,true));content.addView(gap(8))
        val grid=GridLayout(this);grid.columnCount=2
        val data=listOf(
            Triple("Account Balance","$2,147.50","+7.38%"),
            Triple("Today's P&L","+$147.50","+6.9%"),
            Triple("Win Rate","68.4%","+4.2%"),
            Triple("Profit Factor","2.31","+0.18"),
            Triple("Average R","1.42R","+0.11R"),
            Triple("Max Drawdown","-3.80%","Within limit")
        )
        data.forEach{(a,b,c)->val v=stat(a,b,c);grid.addView(v,GridLayout.LayoutParams().apply{width=0;height=142;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(5,5,5,5)})}
        content.addView(grid)
        content.addView(gap(10))
        val eq=box();eq.addView(text("Equity Curve",17f,true));eq.addView(text("Last 30 days",12f,false,Color.LTGRAY))
        eq.addView(text("▁▂▁▃▄▃▅▄▆▇▆▇█▇▉▇█▉",31f,true));eq.addView(text("Starting $2,000  →  Current $2,147.50",12f,false,Color.LTGRAY))
        content.addView(eq)
        content.addView(gap(10))
        val perf=box();perf.addView(text("Performance",17f,true))
        listOf("Best day                 +$182.40","Average win              +$74.20","Average loss             -$38.60","Expectancy               +0.62R","Total trades             38").forEach{perf.addView(text(it,14f))}
        content.addView(perf);content.addView(gap(10))
        val rec=box();rec.addView(text("Recent Trades",17f,true))
        listOf("XAUUSD  •  BUY     +$72.40   +2.1R","NAS100  •  SELL    +$51.20   +1.6R","XAUUSD  •  SELL    -$18.30   -0.6R","BTCUSD  •  BUY     +$42.10   +1.3R").forEach{rec.addView(text(it,14f))}
        content.addView(rec)
    }
    fun trades(){
        base("Trades","ALL EXECUTIONS")
        val filter=box();filter.addView(text("Filters",15f,true));filter.addView(text("All accounts   •   All symbols   •   All setups",13f,false,Color.LTGRAY));content.addView(filter);content.addView(gap(10))
        val list=box();list.addView(text("Trade History",18f,true))
        val rows=listOf("OCT 08  XAUUSD  BUY   +2.10R   +$72.40","OCT 08  NAS100  SELL  +1.60R   +$51.20","OCT 07  XAUUSD  SELL  -0.60R   -$18.30","OCT 06  BTCUSD  BUY   +1.30R   +$42.10","OCT 06  XAUUSD  BUY   +2.70R   +$96.50","OCT 05  NAS100  SELL  -0.90R   -$31.40")
        rows.forEach{list.addView(text(it,13f));list.addView(View(this).apply{setBackgroundColor(Color.DKGRAY);layoutParams=LinearLayout.LayoutParams(-1,1)})}
        content.addView(list)
    }
    fun calendar(){
        base("Calendar","DAILY PERFORMANCE")
        val c=box();c.addView(text("October 2026",20f,true));c.addView(text("MON  TUE  WED  THU  FRI  SAT  SUN",12f,false,Color.LTGRAY))
        c.addView(text("      1     2     3     4\\n5     6     7     8     9    10    11\\n12   13    14    15    16    17    18\\n19   20    21    22    23    24    25\\n26   27    28    29    30    31",18f,true))
        content.addView(c);content.addView(gap(10))
        val p=box();p.addView(text("Monthly Summary",18f,true));listOf("Net P&L                 +$412.80","Profitable days          7","Losing days              3","Best day                 +$147.50","Worst day                -$61.20").forEach{p.addView(text(it,14f))};content.addView(p)
    }
    fun analytics(){
        base("Analytics","PERFORMANCE BREAKDOWN")
        listOf(
            "Risk / Reward" to "Average winner  +1.86R   |   Average loser  -0.74R",
            "Sessions" to "New York  58%   London  31%   Asia  11%",
            "Symbols" to "XAUUSD  61%   NAS100  26%   BTCUSD  13%",
            "Setups" to "Liquidity sweep  72%   Breakout  18%   Other  10%",
            "Discipline" to "Rule adherence  91%   Revenge trades  2"
        ).forEach{(a,b)->val x=box();x.addView(text(a,17f,true));x.addView(text(b,13f,false,Color.LTGRAY));content.addView(x);content.addView(gap(8))}
    }
    fun journal(){
        base("Journal","TRADING PSYCHOLOGY & NOTES")
        val x=box();x.addView(text("Today's Reflection",18f,true));x.addView(text("What went well?",14f,true));x.addView(text("Waited for confirmation and respected risk.",13f,false,Color.LTGRAY));x.addView(text("What to improve?",14f,true));x.addView(text("Avoid entering before the liquidity sweep.",13f,false,Color.LTGRAY));content.addView(x)
        content.addView(gap(10));val m=box();m.addView(text("Mood & Discipline",18f,true));m.addView(text("Focus       ●●●●○\\nConfidence  ●●●●○\\nPatience    ●●●●●\\nStress      ●○○○○",15f));content.addView(m)
    }
    fun addTrade(){
        val d=Dialog(this);val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,25,28,20);setBackgroundColor(card)}
        l.addView(text("Add Trade",22f,true));val sym=EditText(this);sym.hint="Symbol (e.g. XAUUSD)";l.addView(sym)
        val pnl=EditText(this);pnl.hint="P&L ($)";pnl.inputType=2; l.addView(pnl)
        val rr=EditText(this);rr.hint="R multiple";l.addView(rr)
        val notes=EditText(this);notes.hint="Trade notes";l.addView(notes)
        val save=Button(this).apply{text="SAVE TRADE";setOnClickListener{Toast.makeText(this@MainActivity,"Trade saved to A.K Journal",Toast.LENGTH_SHORT).show();d.dismiss()}}
        l.addView(save);d.setContentView(l);d.show()
    }
}