# A.K Journal — Maven-inspired Trading Journal
Android Kotlin project. Designed as a premium dark trading dashboard.
Modules planned: Dashboard, Trades, Calendar, Analytics, Journal, Accounts, Risk.
Build with Android Studio or a cloud Android builder using Gradle.
